#ifndef CONFIG_H
#define CONFIG_H


class config
{
public:
    config();
};

#endif // CONFIG_H