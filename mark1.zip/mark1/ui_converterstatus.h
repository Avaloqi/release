/********************************************************************************
** Form generated from reading UI file 'converterstatus.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONVERTERSTATUS_H
#define UI_CONVERTERSTATUS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ConverterStatus
{
public:
    QPushButton *pb_back;
    QWidget *widget_2;
    QGridLayout *gridLayout;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *widget_8;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_19;
    QLabel *label_20;
    QWidget *widget_9;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_21;
    QLabel *label_22;
    QWidget *widget_10;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_23;
    QLabel *label_24;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;

    void setupUi(QDialog *ConverterStatus)
    {
        if (ConverterStatus->objectName().isEmpty())
            ConverterStatus->setObjectName(QString::fromUtf8("ConverterStatus"));
        ConverterStatus->resize(1024, 600);
        pb_back = new QPushButton(ConverterStatus);
        pb_back->setObjectName(QString::fromUtf8("pb_back"));
        pb_back->setGeometry(QRect(840, 40, 100, 27));
        widget_2 = new QWidget(ConverterStatus);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setGeometry(QRect(90, 110, 571, 321));
        gridLayout = new QGridLayout(widget_2);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(40);
        gridLayout->setVerticalSpacing(10);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        widget_6 = new QWidget(widget_2);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_5 = new QHBoxLayout(widget_6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_13 = new QLabel(widget_6);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setAlignment(Qt::AlignCenter);

        horizontalLayout_5->addWidget(label_13);

        label_14 = new QLabel(widget_6);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setAlignment(Qt::AlignCenter);

        horizontalLayout_5->addWidget(label_14);

        label_15 = new QLabel(widget_6);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setAlignment(Qt::AlignCenter);

        horizontalLayout_5->addWidget(label_15);

        horizontalLayout_5->setStretch(0, 2);
        horizontalLayout_5->setStretch(1, 2);
        horizontalLayout_5->setStretch(2, 1);

        gridLayout->addWidget(widget_6, 7, 0, 1, 1);

        widget_7 = new QWidget(widget_2);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        horizontalLayout_6 = new QHBoxLayout(widget_7);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_16 = new QLabel(widget_7);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setAlignment(Qt::AlignCenter);

        horizontalLayout_6->addWidget(label_16);

        label_17 = new QLabel(widget_7);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setAlignment(Qt::AlignCenter);

        horizontalLayout_6->addWidget(label_17);

        label_18 = new QLabel(widget_7);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setAlignment(Qt::AlignCenter);

        horizontalLayout_6->addWidget(label_18);

        horizontalLayout_6->setStretch(0, 2);
        horizontalLayout_6->setStretch(1, 2);
        horizontalLayout_6->setStretch(2, 1);

        gridLayout->addWidget(widget_7, 8, 0, 1, 1);

        widget = new QWidget(widget_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(label);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(label_2);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(label_3);

        horizontalLayout->setStretch(0, 2);
        horizontalLayout->setStretch(1, 2);
        horizontalLayout->setStretch(2, 1);

        gridLayout->addWidget(widget, 0, 0, 1, 1);

        widget_8 = new QWidget(widget_2);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        horizontalLayout_7 = new QHBoxLayout(widget_8);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_19 = new QLabel(widget_8);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setAlignment(Qt::AlignCenter);

        horizontalLayout_7->addWidget(label_19);

        label_20 = new QLabel(widget_8);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setAlignment(Qt::AlignCenter);

        horizontalLayout_7->addWidget(label_20);

        horizontalLayout_7->setStretch(0, 2);
        horizontalLayout_7->setStretch(1, 2);

        gridLayout->addWidget(widget_8, 0, 1, 1, 1);

        widget_9 = new QWidget(widget_2);
        widget_9->setObjectName(QString::fromUtf8("widget_9"));
        horizontalLayout_8 = new QHBoxLayout(widget_9);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        label_21 = new QLabel(widget_9);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(label_21);

        label_22 = new QLabel(widget_9);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(label_22);

        horizontalLayout_8->setStretch(0, 2);
        horizontalLayout_8->setStretch(1, 2);

        gridLayout->addWidget(widget_9, 1, 1, 1, 1);

        widget_10 = new QWidget(widget_2);
        widget_10->setObjectName(QString::fromUtf8("widget_10"));
        horizontalLayout_9 = new QHBoxLayout(widget_10);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        label_23 = new QLabel(widget_10);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setAlignment(Qt::AlignCenter);

        horizontalLayout_9->addWidget(label_23);

        label_24 = new QLabel(widget_10);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setAlignment(Qt::AlignCenter);

        horizontalLayout_9->addWidget(label_24);

        horizontalLayout_9->setStretch(0, 2);
        horizontalLayout_9->setStretch(1, 2);

        gridLayout->addWidget(widget_10, 2, 1, 1, 1);

        widget_3 = new QWidget(widget_2);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_2 = new QHBoxLayout(widget_3);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(widget_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_4);

        label_5 = new QLabel(widget_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_5);

        label_6 = new QLabel(widget_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_6);

        horizontalLayout_2->setStretch(0, 2);
        horizontalLayout_2->setStretch(1, 2);
        horizontalLayout_2->setStretch(2, 1);

        gridLayout->addWidget(widget_3, 1, 0, 1, 1);

        widget_4 = new QWidget(widget_2);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_3 = new QHBoxLayout(widget_4);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(widget_4);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_7);

        label_8 = new QLabel(widget_4);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_8);

        label_9 = new QLabel(widget_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_9);

        horizontalLayout_3->setStretch(0, 2);
        horizontalLayout_3->setStretch(1, 2);
        horizontalLayout_3->setStretch(2, 1);

        gridLayout->addWidget(widget_4, 2, 0, 1, 1);

        widget_5 = new QWidget(widget_2);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_4 = new QHBoxLayout(widget_5);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_10 = new QLabel(widget_5);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(label_10);

        label_11 = new QLabel(widget_5);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(label_11);

        label_12 = new QLabel(widget_5);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(label_12);

        horizontalLayout_4->setStretch(0, 2);
        horizontalLayout_4->setStretch(1, 2);
        horizontalLayout_4->setStretch(2, 1);

        gridLayout->addWidget(widget_5, 3, 0, 1, 1);


        retranslateUi(ConverterStatus);

        QMetaObject::connectSlotsByName(ConverterStatus);
    } // setupUi

    void retranslateUi(QDialog *ConverterStatus)
    {
        ConverterStatus->setWindowTitle(QCoreApplication::translate("ConverterStatus", "Dialog", nullptr));
        pb_back->setText(QString());
        label_13->setText(QCoreApplication::translate("ConverterStatus", "\350\276\223\345\207\272\350\275\254\347\237\251", nullptr));
        label_14->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_15->setText(QCoreApplication::translate("ConverterStatus", "N.m", nullptr));
        label_16->setText(QCoreApplication::translate("ConverterStatus", "\350\277\220\350\241\214\351\200\237\347\216\207", nullptr));
        label_17->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_18->setText(QCoreApplication::translate("ConverterStatus", "RPM", nullptr));
        label->setText(QCoreApplication::translate("ConverterStatus", "\346\257\215\347\272\277\347\224\265\345\216\213", nullptr));
        label_2->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_3->setText(QCoreApplication::translate("ConverterStatus", "V", nullptr));
        label_19->setText(QCoreApplication::translate("ConverterStatus", "\347\224\265\346\234\272\345\267\245\344\275\234\347\212\266\346\200\201\357\274\232", nullptr));
        label_20->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_21->setText(QCoreApplication::translate("ConverterStatus", "\351\251\261\345\212\250\345\231\250\346\225\205\351\232\234\347\240\201\357\274\232", nullptr));
        label_22->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_23->setText(QCoreApplication::translate("ConverterStatus", "\351\200\232\344\277\241\346\225\205\351\232\234\347\240\201\357\274\232", nullptr));
        label_24->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_4->setText(QCoreApplication::translate("ConverterStatus", "\350\276\223\345\207\272\347\224\265\345\216\213", nullptr));
        label_5->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_6->setText(QCoreApplication::translate("ConverterStatus", "V", nullptr));
        label_7->setText(QCoreApplication::translate("ConverterStatus", "\350\276\223\345\207\272\347\224\265\346\265\201", nullptr));
        label_8->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_9->setText(QCoreApplication::translate("ConverterStatus", "A", nullptr));
        label_10->setText(QCoreApplication::translate("ConverterStatus", "\350\276\223\345\207\272\345\212\237\347\216\207", nullptr));
        label_11->setText(QCoreApplication::translate("ConverterStatus", "0", nullptr));
        label_12->setText(QCoreApplication::translate("ConverterStatus", "W", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ConverterStatus: public Ui_ConverterStatus {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONVERTERSTATUS_H
