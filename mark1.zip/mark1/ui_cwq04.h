/********************************************************************************
** Form generated from reading UI file 'cwq04.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CWQ04_H
#define UI_CWQ04_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cwq04
{
public:
    QWidget *widget;
    QGridLayout *gridLayout;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QComboBox *comboBox;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QComboBox *comboBox_2;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QComboBox *comboBox_3;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QComboBox *comboBox_4;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QComboBox *comboBox_5;

    void setupUi(QDialog *cwq04)
    {
        if (cwq04->objectName().isEmpty())
            cwq04->setObjectName(QString::fromUtf8("cwq04"));
        cwq04->resize(1024, 400);
        widget = new QWidget(cwq04);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(140, 50, 581, 251));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(30);
        gridLayout->setVerticalSpacing(20);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        widget_3 = new QWidget(widget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout = new QHBoxLayout(widget_3);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget_3);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        comboBox = new QComboBox(widget_3);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        horizontalLayout->addWidget(comboBox);

        horizontalLayout->setStretch(0, 1);
        horizontalLayout->setStretch(1, 1);

        gridLayout->addWidget(widget_3, 0, 0, 1, 1);

        widget_4 = new QWidget(widget);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_2 = new QHBoxLayout(widget_4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget_4);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        comboBox_2 = new QComboBox(widget_4);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));

        horizontalLayout_2->addWidget(comboBox_2);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 1);

        gridLayout->addWidget(widget_4, 0, 1, 1, 1);

        widget_5 = new QWidget(widget);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_3 = new QHBoxLayout(widget_5);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget_5);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        comboBox_3 = new QComboBox(widget_5);
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));

        horizontalLayout_3->addWidget(comboBox_3);

        horizontalLayout_3->setStretch(0, 1);
        horizontalLayout_3->setStretch(1, 1);

        gridLayout->addWidget(widget_5, 1, 0, 1, 1);

        widget_6 = new QWidget(widget);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_4 = new QHBoxLayout(widget_6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(widget_6);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        comboBox_4 = new QComboBox(widget_6);
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));

        horizontalLayout_4->addWidget(comboBox_4);

        horizontalLayout_4->setStretch(0, 1);
        horizontalLayout_4->setStretch(1, 1);

        gridLayout->addWidget(widget_6, 1, 1, 1, 1);

        widget_7 = new QWidget(widget);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        horizontalLayout_5 = new QHBoxLayout(widget_7);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(widget_7);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_5->addWidget(label_5);

        comboBox_5 = new QComboBox(widget_7);
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));

        horizontalLayout_5->addWidget(comboBox_5);

        horizontalLayout_5->setStretch(0, 1);
        horizontalLayout_5->setStretch(1, 1);

        gridLayout->addWidget(widget_7, 2, 0, 1, 1);


        retranslateUi(cwq04);

        QMetaObject::connectSlotsByName(cwq04);
    } // setupUi

    void retranslateUi(QDialog *cwq04)
    {
        cwq04->setWindowTitle(QCoreApplication::translate("cwq04", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("cwq04", "\346\213\211\345\233\236\345\212\250\344\275\234\345\212\233\351\207\217\357\274\232", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("cwq04", "\345\205\263", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("cwq04", "\345\274\200", nullptr));

        label_2->setText(QCoreApplication::translate("cwq04", "\347\273\207\346\234\272\347\261\273\345\236\213\357\274\232", nullptr));
        comboBox_2->setItemText(0, QCoreApplication::translate("cwq04", "1", nullptr));
        comboBox_2->setItemText(1, QCoreApplication::translate("cwq04", "2", nullptr));

        label_3->setText(QCoreApplication::translate("cwq04", "\345\210\266\345\212\250\345\274\200\345\247\213\347\202\271\357\274\232      ", nullptr));
        comboBox_3->setItemText(0, QCoreApplication::translate("cwq04", "0.0", nullptr));
        comboBox_3->setItemText(1, QCoreApplication::translate("cwq04", "1.0", nullptr));

        label_4->setText(QCoreApplication::translate("cwq04", "HP\345\210\266\345\212\250\345\212\250\344\275\234\345\212\233\351\207\217\357\274\232", nullptr));
        comboBox_4->setItemText(0, QCoreApplication::translate("cwq04", "1", nullptr));
        comboBox_4->setItemText(1, QCoreApplication::translate("cwq04", "2", nullptr));

        label_5->setText(QCoreApplication::translate("cwq04", "HP\345\210\266\345\212\250\345\212\250\344\275\234\345\271\205\345\272\246\357\274\232", nullptr));
        comboBox_5->setItemText(0, QCoreApplication::translate("cwq04", "\345\205\263", nullptr));
        comboBox_5->setItemText(1, QCoreApplication::translate("cwq04", "\345\274\200", nullptr));

    } // retranslateUi

};

namespace Ui {
    class cwq04: public Ui_cwq04 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CWQ04_H
