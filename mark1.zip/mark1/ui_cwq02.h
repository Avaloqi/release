/********************************************************************************
** Form generated from reading UI file 'cwq02.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CWQ02_H
#define UI_CWQ02_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cwq02
{
public:
    QWidget *widget;
    QGridLayout *gridLayout;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QLabel *label_4;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QLineEdit *lineEdit_3;
    QLabel *label_6;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_7;
    QLineEdit *lineEdit_4;
    QLabel *label_8;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_9;
    QLineEdit *lineEdit_5;
    QLabel *label_10;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_11;
    QLineEdit *lineEdit_6;
    QLabel *label_12;
    QWidget *widget_8;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_13;
    QLineEdit *lineEdit_7;
    QLabel *label_14;
    QWidget *widget_9;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_15;
    QLineEdit *lineEdit_8;
    QLabel *label_16;
    QWidget *widget_10;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_17;
    QLineEdit *lineEdit_9;
    QLabel *label_18;
    QWidget *widget_11;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_19;
    QLineEdit *lineEdit_10;
    QLabel *label_20;
    QWidget *widget_12;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_21;
    QLineEdit *lineEdit_11;
    QLabel *label_22;
    QWidget *widget_13;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_23;
    QLineEdit *lineEdit_12;
    QLabel *label_24;

    void setupUi(QDialog *cwq02)
    {
        if (cwq02->objectName().isEmpty())
            cwq02->setObjectName(QString::fromUtf8("cwq02"));
        cwq02->resize(1024, 400);
        widget = new QWidget(cwq02);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(130, 0, 641, 301));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(20);
        gridLayout->setVerticalSpacing(10);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit = new QLineEdit(widget_2);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(lineEdit);

        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);


        gridLayout->addWidget(widget_2, 0, 0, 1, 1);

        widget_3 = new QWidget(widget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_2 = new QHBoxLayout(widget_3);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        lineEdit_2 = new QLineEdit(widget_3);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(lineEdit_2);

        label_4 = new QLabel(widget_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);


        gridLayout->addWidget(widget_3, 0, 1, 1, 1);

        widget_4 = new QWidget(widget);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_3 = new QHBoxLayout(widget_4);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_5 = new QLabel(widget_4);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_3->addWidget(label_5);

        lineEdit_3 = new QLineEdit(widget_4);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(lineEdit_3);

        label_6 = new QLabel(widget_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_3->addWidget(label_6);


        gridLayout->addWidget(widget_4, 0, 2, 1, 1);

        widget_5 = new QWidget(widget);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_4 = new QHBoxLayout(widget_5);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_7 = new QLabel(widget_5);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_4->addWidget(label_7);

        lineEdit_4 = new QLineEdit(widget_5);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(lineEdit_4);

        label_8 = new QLabel(widget_5);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_4->addWidget(label_8);


        gridLayout->addWidget(widget_5, 1, 0, 1, 1);

        widget_6 = new QWidget(widget);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_5 = new QHBoxLayout(widget_6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_9 = new QLabel(widget_6);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_5->addWidget(label_9);

        lineEdit_5 = new QLineEdit(widget_6);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setAlignment(Qt::AlignCenter);

        horizontalLayout_5->addWidget(lineEdit_5);

        label_10 = new QLabel(widget_6);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_5->addWidget(label_10);


        gridLayout->addWidget(widget_6, 1, 1, 1, 1);

        widget_7 = new QWidget(widget);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        horizontalLayout_6 = new QHBoxLayout(widget_7);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_11 = new QLabel(widget_7);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        horizontalLayout_6->addWidget(label_11);

        lineEdit_6 = new QLineEdit(widget_7);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setAlignment(Qt::AlignCenter);

        horizontalLayout_6->addWidget(lineEdit_6);

        label_12 = new QLabel(widget_7);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        horizontalLayout_6->addWidget(label_12);


        gridLayout->addWidget(widget_7, 1, 2, 1, 1);

        widget_8 = new QWidget(widget);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        horizontalLayout_7 = new QHBoxLayout(widget_8);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_13 = new QLabel(widget_8);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        horizontalLayout_7->addWidget(label_13);

        lineEdit_7 = new QLineEdit(widget_8);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setAlignment(Qt::AlignCenter);

        horizontalLayout_7->addWidget(lineEdit_7);

        label_14 = new QLabel(widget_8);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        horizontalLayout_7->addWidget(label_14);


        gridLayout->addWidget(widget_8, 2, 0, 1, 1);

        widget_9 = new QWidget(widget);
        widget_9->setObjectName(QString::fromUtf8("widget_9"));
        horizontalLayout_8 = new QHBoxLayout(widget_9);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_15 = new QLabel(widget_9);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        horizontalLayout_8->addWidget(label_15);

        lineEdit_8 = new QLineEdit(widget_9);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(lineEdit_8);

        label_16 = new QLabel(widget_9);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        horizontalLayout_8->addWidget(label_16);


        gridLayout->addWidget(widget_9, 2, 1, 1, 1);

        widget_10 = new QWidget(widget);
        widget_10->setObjectName(QString::fromUtf8("widget_10"));
        horizontalLayout_9 = new QHBoxLayout(widget_10);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        label_17 = new QLabel(widget_10);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        horizontalLayout_9->addWidget(label_17);

        lineEdit_9 = new QLineEdit(widget_10);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setAlignment(Qt::AlignCenter);

        horizontalLayout_9->addWidget(lineEdit_9);

        label_18 = new QLabel(widget_10);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        horizontalLayout_9->addWidget(label_18);


        gridLayout->addWidget(widget_10, 2, 2, 1, 1);

        widget_11 = new QWidget(widget);
        widget_11->setObjectName(QString::fromUtf8("widget_11"));
        horizontalLayout_10 = new QHBoxLayout(widget_11);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        label_19 = new QLabel(widget_11);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        horizontalLayout_10->addWidget(label_19);

        lineEdit_10 = new QLineEdit(widget_11);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setAlignment(Qt::AlignCenter);

        horizontalLayout_10->addWidget(lineEdit_10);

        label_20 = new QLabel(widget_11);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        horizontalLayout_10->addWidget(label_20);


        gridLayout->addWidget(widget_11, 3, 0, 1, 1);

        widget_12 = new QWidget(widget);
        widget_12->setObjectName(QString::fromUtf8("widget_12"));
        horizontalLayout_11 = new QHBoxLayout(widget_12);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        label_21 = new QLabel(widget_12);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        horizontalLayout_11->addWidget(label_21);

        lineEdit_11 = new QLineEdit(widget_12);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setAlignment(Qt::AlignCenter);

        horizontalLayout_11->addWidget(lineEdit_11);

        label_22 = new QLabel(widget_12);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        horizontalLayout_11->addWidget(label_22);


        gridLayout->addWidget(widget_12, 3, 1, 1, 1);

        widget_13 = new QWidget(widget);
        widget_13->setObjectName(QString::fromUtf8("widget_13"));
        horizontalLayout_12 = new QHBoxLayout(widget_13);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        label_23 = new QLabel(widget_13);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        horizontalLayout_12->addWidget(label_23);

        lineEdit_12 = new QLineEdit(widget_13);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setAlignment(Qt::AlignCenter);

        horizontalLayout_12->addWidget(lineEdit_12);

        label_24 = new QLabel(widget_13);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        horizontalLayout_12->addWidget(label_24);


        gridLayout->addWidget(widget_13, 3, 2, 1, 1);


        retranslateUi(cwq02);

        QMetaObject::connectSlotsByName(cwq02);
    } // setupUi

    void retranslateUi(QDialog *cwq02)
    {
        cwq02->setWindowTitle(QCoreApplication::translate("cwq02", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("cwq02", " 1\357\274\232", nullptr));
        lineEdit->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_2->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_3->setText(QCoreApplication::translate("cwq02", " 2:", nullptr));
        lineEdit_2->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_4->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_5->setText(QCoreApplication::translate("cwq02", " 3:", nullptr));
        lineEdit_3->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_6->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_7->setText(QCoreApplication::translate("cwq02", " 4:", nullptr));
        lineEdit_4->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_8->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_9->setText(QCoreApplication::translate("cwq02", " 5:", nullptr));
        lineEdit_5->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_10->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_11->setText(QCoreApplication::translate("cwq02", " 6:", nullptr));
        lineEdit_6->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_12->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_13->setText(QCoreApplication::translate("cwq02", " 7:", nullptr));
        lineEdit_7->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_14->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_15->setText(QCoreApplication::translate("cwq02", " 8:", nullptr));
        lineEdit_8->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_16->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_17->setText(QCoreApplication::translate("cwq02", " 9:", nullptr));
        lineEdit_9->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_18->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_19->setText(QCoreApplication::translate("cwq02", "10:", nullptr));
        lineEdit_10->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_20->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_21->setText(QCoreApplication::translate("cwq02", "11:", nullptr));
        lineEdit_11->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_22->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
        label_23->setText(QCoreApplication::translate("cwq02", "12:", nullptr));
        lineEdit_12->setText(QCoreApplication::translate("cwq02", "0", nullptr));
        label_24->setText(QCoreApplication::translate("cwq02", "\345\272\246", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cwq02: public Ui_cwq02 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CWQ02_H
