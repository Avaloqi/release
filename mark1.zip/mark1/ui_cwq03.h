/********************************************************************************
** Form generated from reading UI file 'cwq03.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CWQ03_H
#define UI_CWQ03_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cwq03
{
public:
    QWidget *widget;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QComboBox *comboBox;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QComboBox *comboBox_2;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QComboBox *comboBox_3;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QComboBox *comboBox_4;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QComboBox *comboBox_5;
    QWidget *widget_2;
    QGridLayout *gridLayout;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_13;
    QLabel *label_12;

    void setupUi(QDialog *cwq03)
    {
        if (cwq03->objectName().isEmpty())
            cwq03->setObjectName(QString::fromUtf8("cwq03"));
        cwq03->resize(1024, 400);
        widget = new QWidget(cwq03);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(140, 30, 281, 321));
        widget_3 = new QWidget(widget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        widget_3->setGeometry(QRect(40, 20, 197, 45));
        horizontalLayout = new QHBoxLayout(widget_3);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget_3);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        comboBox = new QComboBox(widget_3);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        horizontalLayout->addWidget(comboBox);

        horizontalLayout->setStretch(0, 1);
        horizontalLayout->setStretch(1, 1);
        widget_4 = new QWidget(widget);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        widget_4->setGeometry(QRect(40, 70, 197, 45));
        horizontalLayout_2 = new QHBoxLayout(widget_4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget_4);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        comboBox_2 = new QComboBox(widget_4);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));

        horizontalLayout_2->addWidget(comboBox_2);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 1);
        widget_5 = new QWidget(widget);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        widget_5->setGeometry(QRect(40, 120, 197, 45));
        horizontalLayout_3 = new QHBoxLayout(widget_5);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget_5);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        comboBox_3 = new QComboBox(widget_5);
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));

        horizontalLayout_3->addWidget(comboBox_3);

        horizontalLayout_3->setStretch(0, 1);
        horizontalLayout_3->setStretch(1, 1);
        widget_6 = new QWidget(widget);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        widget_6->setGeometry(QRect(40, 170, 197, 45));
        horizontalLayout_4 = new QHBoxLayout(widget_6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(widget_6);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        comboBox_4 = new QComboBox(widget_6);
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));

        horizontalLayout_4->addWidget(comboBox_4);

        horizontalLayout_4->setStretch(0, 1);
        horizontalLayout_4->setStretch(1, 1);
        widget_7 = new QWidget(widget);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        widget_7->setGeometry(QRect(40, 230, 197, 45));
        horizontalLayout_5 = new QHBoxLayout(widget_7);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(widget_7);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_5->addWidget(label_5);

        comboBox_5 = new QComboBox(widget_7);
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));

        horizontalLayout_5->addWidget(comboBox_5);

        horizontalLayout_5->setStretch(0, 1);
        horizontalLayout_5->setStretch(1, 1);
        widget_2 = new QWidget(cwq03);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setGeometry(QRect(470, 40, 151, 251));
        gridLayout = new QGridLayout(widget_2);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(widget_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_6, 0, 0, 1, 1);

        label_7 = new QLabel(widget_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_7, 0, 1, 1, 1);

        label_8 = new QLabel(widget_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_8, 1, 0, 1, 1);

        label_9 = new QLabel(widget_2);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_9, 1, 1, 1, 1);

        label_10 = new QLabel(widget_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_10, 2, 0, 1, 1);

        label_11 = new QLabel(widget_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_11, 2, 1, 1, 1);

        label_13 = new QLabel(widget_2);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_13, 3, 0, 1, 1);

        label_12 = new QLabel(widget_2);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_12, 3, 1, 1, 1);


        retranslateUi(cwq03);

        QMetaObject::connectSlotsByName(cwq03);
    } // setupUi

    void retranslateUi(QDialog *cwq03)
    {
        cwq03->setWindowTitle(QCoreApplication::translate("cwq03", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("cwq03", "\346\243\200\347\272\261\351\253\230\345\272\246\357\274\232", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("cwq03", "\344\275\216", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("cwq03", "\351\253\230", nullptr));

        label_2->setText(QCoreApplication::translate("cwq03", "\346\226\255\347\272\261\345\201\234\350\275\246\357\274\232", nullptr));
        comboBox_2->setItemText(0, QCoreApplication::translate("cwq03", "\345\274\200", nullptr));
        comboBox_2->setItemText(1, QCoreApplication::translate("cwq03", "\345\205\263", nullptr));

        label_3->setText(QCoreApplication::translate("cwq03", "\345\217\214\345\234\210\346\243\200\346\265\213\357\274\232", nullptr));
        comboBox_3->setItemText(0, QCoreApplication::translate("cwq03", "\345\274\200", nullptr));
        comboBox_3->setItemText(1, QCoreApplication::translate("cwq03", "\345\205\263", nullptr));

        label_4->setText(QCoreApplication::translate("cwq03", "\346\257\233\347\276\275\350\277\207\346\273\244\357\274\232", nullptr));
        comboBox_4->setItemText(0, QCoreApplication::translate("cwq03", "0%", nullptr));
        comboBox_4->setItemText(1, QCoreApplication::translate("cwq03", "10%", nullptr));
        comboBox_4->setItemText(2, QCoreApplication::translate("cwq03", "20%", nullptr));
        comboBox_4->setItemText(3, QCoreApplication::translate("cwq03", "30%", nullptr));
        comboBox_4->setItemText(4, QCoreApplication::translate("cwq03", "40%", nullptr));
        comboBox_4->setItemText(5, QCoreApplication::translate("cwq03", "50%", nullptr));
        comboBox_4->setItemText(6, QCoreApplication::translate("cwq03", "60%", nullptr));
        comboBox_4->setItemText(7, QCoreApplication::translate("cwq03", "70%", nullptr));
        comboBox_4->setItemText(8, QCoreApplication::translate("cwq03", "80%", nullptr));
        comboBox_4->setItemText(9, QCoreApplication::translate("cwq03", "90%", nullptr));
        comboBox_4->setItemText(10, QCoreApplication::translate("cwq03", "100%", nullptr));

        label_5->setText(QCoreApplication::translate("cwq03", "\345\244\226\351\203\250\350\207\252\345\201\234\357\274\232", nullptr));
        comboBox_5->setItemText(0, QCoreApplication::translate("cwq03", "\345\274\200", nullptr));
        comboBox_5->setItemText(1, QCoreApplication::translate("cwq03", "\345\205\263", nullptr));

        label_6->setText(QCoreApplication::translate("cwq03", "\350\256\241\345\234\210\357\274\232", nullptr));
        label_7->setText(QCoreApplication::translate("cwq03", "0", nullptr));
        label_8->setText(QCoreApplication::translate("cwq03", "\346\226\255\347\272\261\357\274\232", nullptr));
        label_9->setText(QCoreApplication::translate("cwq03", "0", nullptr));
        label_10->setText(QCoreApplication::translate("cwq03", "PotZ:", nullptr));
        label_11->setText(QCoreApplication::translate("cwq03", "0", nullptr));
        label_13->setText(QCoreApplication::translate("cwq03", "PotT:", nullptr));
        label_12->setText(QCoreApplication::translate("cwq03", "0", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cwq03: public Ui_cwq03 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CWQ03_H
