/********************************************************************************
** Form generated from reading UI file 'jingshajiance.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_JINGSHAJIANCE_H
#define UI_JINGSHAJIANCE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_JingShaJianCe
{
public:
    QPushButton *pb_back;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QDialogButtonBox *bB00;
    QWidget *widget_9;
    QGridLayout *gridLayout;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QDialogButtonBox *bB01;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_7;
    QDialogButtonBox *bB06;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QDialogButtonBox *bB02;
    QWidget *widget_8;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_8;
    QDialogButtonBox *bB07;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QDialogButtonBox *bB03;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QDialogButtonBox *bB04;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_6;
    QDialogButtonBox *bB05;

    void setupUi(QDialog *JingShaJianCe)
    {
        if (JingShaJianCe->objectName().isEmpty())
            JingShaJianCe->setObjectName(QString::fromUtf8("JingShaJianCe"));
        JingShaJianCe->resize(1024, 600);
        pb_back = new QPushButton(JingShaJianCe);
        pb_back->setObjectName(QString::fromUtf8("pb_back"));
        pb_back->setGeometry(QRect(860, 30, 100, 27));
        widget = new QWidget(JingShaJianCe);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(90, 60, 266, 50));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(5);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        bB00 = new QDialogButtonBox(widget);
        bB00->setObjectName(QString::fromUtf8("bB00"));
        bB00->setStandardButtons(QDialogButtonBox::NoButton);

        horizontalLayout->addWidget(bB00);

        widget_9 = new QWidget(JingShaJianCe);
        widget_9->setObjectName(QString::fromUtf8("widget_9"));
        widget_9->setGeometry(QRect(90, 150, 711, 341));
        gridLayout = new QGridLayout(widget_9);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(80);
        gridLayout->setVerticalSpacing(10);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        widget_2 = new QWidget(widget_9);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout_2 = new QHBoxLayout(widget_2);
        horizontalLayout_2->setSpacing(5);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        bB01 = new QDialogButtonBox(widget_2);
        bB01->setObjectName(QString::fromUtf8("bB01"));
        bB01->setStandardButtons(QDialogButtonBox::NoButton);

        horizontalLayout_2->addWidget(bB01);


        gridLayout->addWidget(widget_2, 0, 0, 1, 1);

        widget_7 = new QWidget(widget_9);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        horizontalLayout_7 = new QHBoxLayout(widget_7);
        horizontalLayout_7->setSpacing(5);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(widget_7);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_7->addWidget(label_7);

        bB06 = new QDialogButtonBox(widget_7);
        bB06->setObjectName(QString::fromUtf8("bB06"));
        bB06->setStandardButtons(QDialogButtonBox::NoButton);

        horizontalLayout_7->addWidget(bB06);


        gridLayout->addWidget(widget_7, 0, 1, 1, 1);

        widget_3 = new QWidget(widget_9);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_3 = new QHBoxLayout(widget_3);
        horizontalLayout_3->setSpacing(5);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        bB02 = new QDialogButtonBox(widget_3);
        bB02->setObjectName(QString::fromUtf8("bB02"));
        bB02->setStandardButtons(QDialogButtonBox::NoButton);

        horizontalLayout_3->addWidget(bB02);


        gridLayout->addWidget(widget_3, 1, 0, 1, 1);

        widget_8 = new QWidget(widget_9);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        horizontalLayout_8 = new QHBoxLayout(widget_8);
        horizontalLayout_8->setSpacing(5);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(widget_8);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_8->addWidget(label_8);

        bB07 = new QDialogButtonBox(widget_8);
        bB07->setObjectName(QString::fromUtf8("bB07"));
        bB07->setStandardButtons(QDialogButtonBox::NoButton);

        horizontalLayout_8->addWidget(bB07);


        gridLayout->addWidget(widget_8, 1, 1, 1, 1);

        widget_4 = new QWidget(widget_9);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_4 = new QHBoxLayout(widget_4);
        horizontalLayout_4->setSpacing(5);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(widget_4);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        bB03 = new QDialogButtonBox(widget_4);
        bB03->setObjectName(QString::fromUtf8("bB03"));
        bB03->setStandardButtons(QDialogButtonBox::NoButton);

        horizontalLayout_4->addWidget(bB03);


        gridLayout->addWidget(widget_4, 2, 0, 1, 1);

        widget_5 = new QWidget(widget_9);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_5 = new QHBoxLayout(widget_5);
        horizontalLayout_5->setSpacing(5);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(widget_5);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_5->addWidget(label_5);

        bB04 = new QDialogButtonBox(widget_5);
        bB04->setObjectName(QString::fromUtf8("bB04"));
        bB04->setStandardButtons(QDialogButtonBox::NoButton);

        horizontalLayout_5->addWidget(bB04);


        gridLayout->addWidget(widget_5, 3, 0, 1, 1);

        widget_6 = new QWidget(widget_9);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_6 = new QHBoxLayout(widget_6);
        horizontalLayout_6->setSpacing(5);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(widget_6);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_6->addWidget(label_6);

        bB05 = new QDialogButtonBox(widget_6);
        bB05->setObjectName(QString::fromUtf8("bB05"));
        bB05->setStandardButtons(QDialogButtonBox::NoButton);

        horizontalLayout_6->addWidget(bB05);


        gridLayout->addWidget(widget_6, 4, 0, 1, 1);


        retranslateUi(JingShaJianCe);

        QMetaObject::connectSlotsByName(JingShaJianCe);
    } // setupUi

    void retranslateUi(QDialog *JingShaJianCe)
    {
        JingShaJianCe->setWindowTitle(QCoreApplication::translate("JingShaJianCe", "Dialog", nullptr));
        pb_back->setText(QString());
        label->setText(QCoreApplication::translate("JingShaJianCe", "\345\205\250\351\203\250\345\220\257\347\224\250\357\274\232", nullptr));
        label_2->setText(QCoreApplication::translate("JingShaJianCe", "\345\201\234\347\273\217\347\211\207\357\274\232", nullptr));
        label_7->setText(QCoreApplication::translate("JingShaJianCe", "\346\226\255\347\272\277\346\243\200\346\265\213\357\274\232", nullptr));
        label_3->setText(QCoreApplication::translate("JingShaJianCe", "\350\277\207\345\274\240\345\212\233\357\274\232", nullptr));
        label_8->setText(QCoreApplication::translate("JingShaJianCe", "\347\273\236\350\276\271\346\243\200\346\265\213\357\274\232", nullptr));
        label_4->setText(QCoreApplication::translate("JingShaJianCe", "\345\267\246\347\273\236\350\276\271\357\274\232", nullptr));
        label_5->setText(QCoreApplication::translate("JingShaJianCe", "\345\211\215\345\272\237\347\211\207\357\274\232", nullptr));
        label_6->setText(QCoreApplication::translate("JingShaJianCe", "\345\220\216\345\272\237\347\211\207\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class JingShaJianCe: public Ui_JingShaJianCe {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_JINGSHAJIANCE_H
